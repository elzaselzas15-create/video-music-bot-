# Video Music Bot
Telegram bot that receives a video and sends 6 short original background-music MP3 options.

Set the environment variable `BOT_TOKEN` to the token from BotFather. Keep it private.
