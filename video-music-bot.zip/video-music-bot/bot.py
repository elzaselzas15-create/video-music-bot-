import os, tempfile, subprocess, math, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
import numpy as np
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

TOKEN = os.environ.get('BOT_TOKEN')

class Health(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200); self.end_headers(); self.wfile.write(b'OK')
    def log_message(self, *args): pass

def health_server():
    port=int(os.environ.get('PORT','10000'))
    HTTPServer(('0.0.0.0',port),Health).serve_forever()

def make_track(path, mood, seed):
    sr=44100; dur=18; n=sr*dur; t=np.arange(n)/sr
    rng=np.random.default_rng(seed)
    bpm={'cinematic':78,'emotional':66,'energetic':124,'calm':72,'dark':84,'upbeat':112}[mood]
    beat=60/bpm
    scales={'cinematic':[0,3,7,10],'emotional':[0,3,5,8],'energetic':[0,2,4,7],'calm':[0,2,5,7],'dark':[0,1,5,6],'upbeat':[0,4,7,9]}
    base=220*2**(-12/12)
    x=np.zeros(n,dtype=np.float32)
    notes=scales[mood]
    for k,start in enumerate(np.arange(0,dur,beat)):
        idx=int(start*sr); end=min(n,idx+int(beat*0.9*sr)); tt=t[:end-idx]
        note=notes[k%len(notes)] + (12 if (k//len(notes))%2 else 0)
        f=base*2**(note/12)
        env=np.exp(-3*tt/max(beat,0.01))
        x[idx:end]+=0.22*np.sin(2*np.pi*f*tt)*env
        x[idx:end]+=0.10*np.sin(2*np.pi*f*2*tt)*env
    # soft pad
    f2=base*2**(notes[0]/12)/2
    x += 0.10*np.sin(2*np.pi*f2*t) * (0.5+0.5*np.sin(2*np.pi*t/dur))
    x += rng.normal(0,0.008,n).astype(np.float32)
    x=np.tanh(x*2.0); x/=max(np.max(np.abs(x)),1e-6); x*=0.75
    wav=path.replace('.mp3','.wav')
    import wave
    with wave.open(wav,'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((x*32767).astype(np.int16).tobytes())
    subprocess.run(['ffmpeg','-y','-loglevel','error','-i',wav,'-codec:a','libmp3lame','-b:a','128k',path],check=True)
    os.remove(wav)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text('🎬 Видеоны жіберіңіз. Мен оған сай 6 түрлі түпнұсқа фондық музыка дайындауға тырысамын.')

async def video(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg=await update.message.reply_text('⏳ Видео қабылданды. 6 нұсқа дайындалып жатыр...')
    tgfile=await update.message.video.get_file()
    with tempfile.TemporaryDirectory() as d:
        inp=os.path.join(d,'video.mp4'); await tgfile.download_to_drive(inp)
        # Basic loudness analysis; used only to choose a general set of styles.
        loud=0.0
        try:
            p=subprocess.run(['ffmpeg','-i',inp,'-vn','-af','volumedetect','-f','null','-'],stderr=subprocess.PIPE,stdout=subprocess.DEVNULL,text=True)
            import re
            m=re.search(r'mean_volume:\s*(-?[0-9.]+) dB',p.stderr)
            if m: loud=float(m.group(1))
        except Exception: pass
        moods=['cinematic','emotional','energetic','calm','dark','upbeat']
        for i,mood in enumerate(moods,1):
            out=os.path.join(d,f'{i}_{mood}.mp3'); make_track(out,mood,i)
            await update.message.reply_audio(audio=open(out,'rb'),caption=f'🎵 {i}/6 — {mood.capitalize()}')
    await msg.edit_text('✅ Дайын! 6 музыкалық нұсқа жіберілді.')

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()

def main():
    if not TOKEN: raise RuntimeError('BOT_TOKEN is not set')
    threading.Thread(target=health_server,daemon=True).start()
    app=Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler('start',start))
    app.add_handler(MessageHandler(filters.VIDEO,video))
    app.add_handler(CallbackQueryHandler(button))
    app.run_polling(drop_pending_updates=True)
if __name__=='__main__': main()
